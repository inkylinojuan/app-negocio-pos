<!-- src/pages/AdminDashboard.vue -->
<template>
    <div class="container mt-5">
      <h2>Admin Dashboard</h2>
      <p>Bienvenido al panel de administración del negocio.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'AdminDashboard'
  }
  </script>
  
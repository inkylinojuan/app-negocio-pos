<template>
    <div class="container mt-5">
      <h1>Operative Dashboard</h1>
      <p>Bienvenido, Operativo.</p>
      <p>Aquí podrías mostrar el turno actual, un acceso al POS, etc.</p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'OperativeDashboard'
  }
  </script>
  
<template>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
      <div class="container-fluid">
        <!-- Marca o logo -->
        <div @click="closeMenu">
          <b>Inventario</b>
        </div>
        <!-- Botón para colapsar el menú en pantallas pequeñas -->
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Menú de navegación -->
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <router-link class="nav-link" to="/inventario/inicio" @click="closeMenu">
                Activos Disponibles
              </router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/inventario/verActivo" @click="closeMenu">
                Ver Activo por RFID
              </router-link>
            </li>
            <!--<li class="nav-item">
              <router-link class="nav-link" to="/inventario/single" @click="closeMenu">
                Ingresar
              </router-link>
            </li>-->
            <li class="nav-item">
              <router-link class="nav-link" to="/inventario/all" @click="closeMenu">
                Lectura Completa
              </router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/inventario/bodegas" @click="closeMenu">
                Bodegas
              </router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/inventario/IngresarActivos" @click="closeMenu">
                Ingresar Activos
              </router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </template>
  
  <script>
  export default {
    name: "MenuInventario",
    methods: {
      closeMenu() {
        // Obtiene el elemento colapsable del menú
        const collapseElement = document.getElementById("navbarSupportedContent");
        if (collapseElement && window.bootstrap && window.bootstrap.Collapse) {
          // Intenta obtener una instancia existente de Collapse
          const collapseInstance = window.bootstrap.Collapse.getInstance(collapseElement);
          if (collapseInstance) {
            collapseInstance.hide();
          } else {
            // Si no existe, crea una nueva instancia y la oculta
            new window.bootstrap.Collapse(collapseElement, { toggle: false }).hide();
          }
        }
      }
    }
  };
  </script>
  
  <style scoped>
  /* Puedes agregar estilos personalizados si es necesario */
  </style>
  
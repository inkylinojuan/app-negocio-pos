<template>
  <div class="sidebar">
    <div class="sidebar-header">
      <router-link class="sidebar-brand" to="/">
        {{ businessInfo.name || 'Cargando...' }}
      </router-link>
      <p>Rol: {{ userRole || 'Cargando...' }}</p>
    </div>
  </div>
  <div>
    <ul class="sidebar-menu">
      <!-- Menú para Admin -->
      <template v-if="userRole === 'admin'">
        <li>
          <router-link to="/admin/products">Productos</router-link>
        </li>
        <li>
          <router-link to="/admin/turns">Turnos</router-link>
        </li>
        <li>
          <router-link to="/admin/expenses">Gastos</router-link>
        </li>
        <li>
          <router-link to="/admin/reports">Reportes</router-link>
        </li>
        <li>
          <router-link to="/admin/register-user">Registrar Usuario</router-link>
        </li>
        <li>
          <router-link to="/admin/domicilio">Domicilios</router-link>
        </li>
        <li>
          <router-link to="/admin/combos">Combos</router-link>
        </li>
        <li>
          <router-link to="/admin/contacts">Contactos</router-link>
        </li>
      </template>
      <!-- Menú para Operativos -->
      <template v-if="userRole === 'operative'">
        <li>
          <router-link to="/operative/turn">Turno</router-link>
        </li>
        <li>
          <router-link to="/operative/pos">Punto de Venta</router-link>
        </li>
        <li>
          <router-link to="/operative/domicilio">Domicilios</router-link>
        </li>
        <li v-if="currentTurnId">
          <router-link :to="`/operative/turn-sales-summary/${currentTurnId}`">
            Resumen de Ventas
          </router-link>
        </li>
        <li>
          <router-link to="/operative/contacts">Contactos</router-link>
        </li>
      </template>
    </ul>
    <div class="sidebar-footer">
      <button class="btn btn-outline-light btn-sm" @click="logout">Logout</button>
    </div>
  </div>
</template>

<script>
import { ref, onMounted, computed } from 'vue'
import { signOut } from 'firebase/auth'
import { auth } from '../firebase'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'


export default {
  name: 'Menu',
  setup() {
    const authStore = useAuthStore()
    const businessInfo = computed(() => authStore.businessInfo)
    const userRole = computed(() => authStore.userRole)  
    console.log(userRole.value)
    console.log(authStore.userRole);
    const currentTurnId = ref('')
    const router = useRouter()

    onMounted(() => {
      currentTurnId.value = localStorage.getItem('currentTurnId') || ''
      console.log("Current Turn ID:", currentTurnId.value)
    })

    const logout = async () => {
      await signOut(auth)
      localStorage.removeItem('userRole')
      router.push('/login')
    }

    return { userRole, logout, currentTurnId, businessInfo }
  }
}
</script>

<style scoped>
.sidebar {
  height: 100vh;
  width: 250px;
  background-color: #343a40;
  color: #fff;
  position: fixed;
  top: 0;
  left: 0;
  padding: 1rem;
  overflow-y: auto;
}

.sidebar-header {
  margin-bottom: 1rem;
}

.sidebar-brand {
  font-size: 1.5rem;
  color: #fff;
  text-decoration: none;
}

.sidebar-menu {
  list-style: none;
  padding: 0;
  margin: 0;
}

.sidebar-menu li {
  margin: 1rem 0;
}

.sidebar-menu li a {
  color: #fff;
  text-decoration: none;
}

.sidebar-footer {
  position: absolute;
  bottom: 1rem;
  width: 100%;
  text-align: center;
}
</style>

import { createRouter, createWebHistory } from 'vue-router'
import { onAuthStateChanged } from 'firebase/auth'
import { auth } from './firebase'

// Importar páginas
import Login from './pages/Login.vue'
import AdminDashboard from './pages/AdminDashboard.vue'
import Products from './pages/Products.vue'
import TurnList from './pages/TurnList.vue'
import TurnDetail from './pages/TurnDetail.vue'
import Expenses from './pages/Expenses.vue'
import Reports from './pages/Reports.vue'
import RegisterUser from './pages/RegisterUser.vue'
import Domicilio from './pages/Domicilio.vue'
import OperativeDashboard from './pages/OperativeDashboard.vue'
import SalesPOS from './pages/SalesPOS.vue'
import TurnManager from './pages/TurnManager.vue'
import DomicilioOperativo from './pages/DomicilioOperativo.vue'
import TurnSalesSummary from './pages/TurnSalesSummary.vue'
import ComboManager from './components/ComboManager.vue'
import CreateBusiness from './pages/CreateBusiness.vue'
import ContactsManager from './components/ContactsManager.vue'
import PrintInvoice from './pages/PrintInvoice.vue'


const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', name: 'Login', component: Login },
  // Rutas para Superadmin
  {
    path: '/superadmin/create-business',
    name: 'CreateBusiness',
    component: CreateBusiness,
    meta: { requiresAuth: true, role: 'superadmin' }
  },
  // Rutas para Admin
  {
    path: '/admin',
    name: 'AdminDashboard',
    component: AdminDashboard,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/products',
    name: 'Products',
    component: Products,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/turns',
    name: 'TurnList',
    component: TurnList,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/turns/:id',
    name: 'TurnDetail',
    component: TurnDetail,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/expenses',
    name: 'Expenses',
    component: Expenses,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/reports',
    name: 'Reports',
    component: Reports,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/register-user',
    name: 'RegisterUser',
    component: RegisterUser,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/domicilio',
    name: 'Domicilio',
    component: Domicilio,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/combos',   // Nueva ruta para ComboManager
    name: 'ComboManager',
    component: ComboManager,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/contacts',   // Nueva ruta para ContactsManager
    name: 'ContactsManager',
    component: ContactsManager,
    meta: { requiresAuth: true, role: 'admin' }
  },
  {
    path: '/admin/turn-sales-summary/:turnId',
    name: 'AdminTurnSalesSummary',
    component: TurnSalesSummary,
    meta: { requiresAuth: true, role: 'admin' }
  },
  // Rutas para Operativos
  {
    path: '/operative',
    name: 'OperativeDashboard',
    component: OperativeDashboard,
    meta: { requiresAuth: true, role: 'operative' }
  },
  {
    path: '/operative/pos',
    name: 'SalesPOS',
    component: SalesPOS,
    props: () => ({ businessId: localStorage.getItem('businessId') || '' }),
    meta: { requiresAuth: true, role: 'operative' }
  },
  {
    path: '/operative/turn',
    name: 'TurnManager',
    component: TurnManager,
    meta: { requiresAuth: true, role: 'operative' }
  },
  {
    path: '/operative/domicilio',
    name: 'DomicilioOperativo',
    component: DomicilioOperativo,
    meta: { requiresAuth: true, role: 'operative' }
  },
  {
    path: '/operative/turn-sales-summary/:turnId',
    name: 'OperativeTurnSalesSummary',
    component: TurnSalesSummary,
    meta: { requiresAuth: true, role: 'operative' }
  },
  {
    path: '/operative/contacts',   // Nueva ruta para ContactsManager
    name: 'ContactsManager',
    component: ContactsManager,
    meta: { requiresAuth: true, role: 'operative' }
  },
  {
    path: '/print-invoice',
    name: 'PrintInvoice',
    component: PrintInvoice
  },
]

// ... El resto del código del router (onAuthStateChanged, etc.)


const router = createRouter({
    history: createWebHistory(),
    routes
  })
  
  router.beforeEach((to, from, next) => {
    if (!to.meta.requiresAuth) return next()
  
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      unsubscribe()
      if (!user) {
        next('/login')
      } else {
        const userRole = localStorage.getItem('userRole')
        if (to.meta.role && to.meta.role !== userRole) next('/login')
        else next()
      }
    })
  })

export default router

// src/stores/auth.js
import { defineStore } from 'pinia'

export const useAuthStore = defineStore('auth', {
  state: () => ({
    fullName: '',
    userRole: '',
    businessId: '',
    businessInfo: {}
  }),
  actions: {
    setUserInfo({ fullName, userRole, businessId }) {
      this.fullName = fullName
      this.userRole = userRole
      this.businessId = businessId
    },
    setBusinessInfo(businessInfo) {
      this.businessInfo = businessInfo
    },
    clear() {
      this.fullName = ''
      this.userRole = ''
      this.businessId = ''
      this.businessInfo = {}
    }
  },
  persist: true, // Esto hace que el store se guarde en localStorage
  getters: {
    isAdmin: (state) => state.userRole === 'admin',
    isSuperAdmin: (state) => state.userRole === 'superadmin'
  }
})

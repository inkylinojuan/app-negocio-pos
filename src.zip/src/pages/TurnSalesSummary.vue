<template>
    <div class="container mt-5">
      <h2>Resumen de Ventas del Turno</h2>
      <p>
        Turno: <strong>{{ turnId }}</strong>
      </p>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Número de Factura</th>
            <th>Monto Total</th>
            <th>Medio de Pago</th>
            <th>Tipo de Venta</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="invoice in invoices" :key="invoice.id">
            <td>{{ invoice.id }}</td>
            <td>{{ invoice.total }}</td>
            <td>{{ invoice.paymentMethodDisplay }}</td>
            <td>
              <!-- Consideramos que 'delivery' es venta por mensajería y lo demás son ventas directas -->
              <span v-if="invoice.paymentMethod === 'delivery'">Mensajería</span>
              <span v-else>Directa</span>
            </td>
            <td>
              <button class="btn btn-info btn-sm" @click="viewInvoice(invoice)">Ver Factura</button>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <th colspan="5">Totales</th>
          </tr>
          <tr>
            <td colspan="2"><strong>Total Ventas Directas:</strong></td>
            <td colspan="3">{{ totalDirectSales }}</td>
          </tr>
          <tr>
            <td colspan="2"><strong>Total Ventas Mensajería:</strong></td>
            <td colspan="3">{{ totalDeliverySales }}</td>
          </tr>
          <tr>
            <td colspan="2"><strong>Total General:</strong></td>
            <td colspan="3">{{ totalGeneralSales }}</td>
          </tr>
        </tfoot>
      </table>
  
      <!-- Modal para ver la factura -->
      <div class="modal fade" id="invoiceModal" tabindex="-1" aria-labelledby="invoiceModalLabel" aria-hidden="true" ref="invoiceModal">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="invoiceModalLabel">Factura: {{ selectedInvoice.id }}</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" @click="closeModal"></button>
            </div>
            <div class="modal-body">
              <!-- Aquí puedes reutilizar el componente Invoice para mostrar la factura -->
              <Invoice 
                :cart="selectedInvoice.cart" 
                :total="selectedInvoice.total" 
                :paymentMethod="selectedInvoice.paymentMethod"
                :cashReceived="selectedInvoice.cashReceived || 0"
                :change="selectedInvoice.change || 0"
                :isDelivery="selectedInvoice.paymentMethod === 'delivery'" 
              />
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal" @click="closeModal">Cerrar</button>
              <button type="button" class="btn btn-primary" @click="printInvoice">Imprimir</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { ref, onMounted, computed } from 'vue'
  import { collection, query, where, getDocs } from 'firebase/firestore'
  import { db } from '../firebase'
  import Invoice from '../components/Invoice.vue'
  import { useRoute } from 'vue-router'
  
  export default {
    name: 'TurnSalesSummary',
    components: { Invoice },
    setup() {
      const route = useRoute()
      const turnId = route.params.turnId
      const invoices = ref([])
      const selectedInvoice = ref({})
      const businessId = localStorage.getItem('businessId') || ''
  
      const fetchInvoices = async () => {
        const invoicesCol = collection(db, 'businesses', businessId, 'invoices')
        // Filtrar facturas del turno actual
        const q = query(invoicesCol, where('turnId', '==', turnId))
        const snap = await getDocs(q)
        invoices.value = snap.docs.map(doc => {
          const data = doc.data()
          return { 
            id: doc.id, 
            ...data,
            paymentMethodDisplay: data.paymentMethod === 'cash' ? 'Efectivo' : data.paymentMethod === 'qr' ? 'QR / Transferencia' : 'Domicilio'
          }
        })
      }
  
      onMounted(() => {
        fetchInvoices()
      })
  
      // Totales por tipo de venta
      const totalDirectSales = computed(() => {
        return invoices.value
          .filter(inv => inv.paymentMethod !== 'delivery')
          .reduce((sum, inv) => sum + (inv.total || 0), 0)
      })
  
      const totalDeliverySales = computed(() => {
        return invoices.value
          .filter(inv => inv.paymentMethod === 'delivery')
          .reduce((sum, inv) => sum + (inv.total || 0), 0)
      })
  
      const totalGeneralSales = computed(() => totalDirectSales.value + totalDeliverySales.value)
  
      // Funciones para ver factura en modal
      const invoiceModal = ref(null)
      const viewInvoice = (invoice) => {
        selectedInvoice.value = invoice
        // Mostrar modal usando Bootstrap
        invoiceModal.value = new bootstrap.Modal(document.getElementById('invoiceModal'))
        invoiceModal.value.show()
      }
  
      const closeModal = () => {
        if (invoiceModal.value) {
          invoiceModal.value.hide()
        }
      }
  
      const printInvoice = () => {
        window.print()
      }
  
      return {
        turnId,
        invoices,
        selectedInvoice,
        totalDirectSales,
        totalDeliverySales,
        totalGeneralSales,
        viewInvoice,
        closeModal,
        printInvoice
      }
    }
  }
  </script>
  
  <style scoped>
  /* Agrega estilos personalizados según necesites */
  </style>
  
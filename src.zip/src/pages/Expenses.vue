<template>
    <div class="container mt-5">
      <h2>Registrar Gasto</h2>
      <form @submit.prevent="addExpense" class="row g-3">
        <div class="col-md-4">
          <label>Monto</label>
          <input v-model.number="newExpense.amount" type="number" class="form-control" placeholder="Monto" />
        </div>
        <div class="col-md-6">
          <label>Descripción</label>
          <input v-model="newExpense.description" type="text" class="form-control" placeholder="Descripción" />
        </div>
        <div class="col-md-2 d-flex align-items-end">
          <button type="submit" class="btn btn-primary">Agregar</button>
        </div>
      </form>
  
      <h3 class="mt-4">Gastos Registrados</h3>
      <ul class="list-group">
        <li class="list-group-item" v-for="expense in expenses" :key="expense.id">
          {{ expense.description }} - \${{ expense.amount }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  import { ref, onMounted } from 'vue'
  import { db } from '../firebase'
  import { collection, addDoc, getDocs, query, where, serverTimestamp } from 'firebase/firestore'
  import { useRoute } from 'vue-router'
  
  export default {
    name: 'Expenses',
    setup() {
      const route = useRoute()
      const businessId = localStorage.getItem('businessId') || ''
      // Suponiendo que el turno actual se pasa por parámetro; de lo contrario, se puede obtener del store
      const turnId = route.params.turnId || 'currentTurnId'
      const newExpense = ref({
        amount: 0,
        description: ''
      })
      const expenses = ref([])
  
      const expensesCol = collection(db, 'businesses', businessId, 'expenses')
  
      const fetchExpenses = async () => {
        const q = query(expensesCol, where('turnId', '==', turnId))
        const snap = await getDocs(q)
        expenses.value = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
      }
  
      const addExpense = async () => {
        if (!newExpense.value.description || newExpense.value.amount <= 0) return
        await addDoc(expensesCol, {
          turnId,
          amount: newExpense.value.amount,
          description: newExpense.value.description,
          createdAt: serverTimestamp()
        })
        newExpense.value = { amount: 0, description: '' }
        fetchExpenses()
      }
  
      onMounted(() => {
        fetchExpenses()
      })
  
      return {
        newExpense,
        expenses,
        addExpense
      }
    }
  }
  </script>
  
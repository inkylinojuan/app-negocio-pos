<template>
  <div class="container mt-5">
    <h2>Gestión de Productos</h2>
    <form @submit.prevent="addProduct" class="row g-3 mb-3">
      <div class="col-md-3">
        <input
          v-model="newProduct.name"
          type="text"
          class="form-control"
          placeholder="Nombre"
        />
      </div>
      <div class="col-md-2">
        <input
          v-model.number="newProduct.priceSale"
          type="number"
          class="form-control"
          placeholder="Precio Venta"
        />
      </div>
      <div class="col-md-2">
        <input
          v-model.number="newProduct.priceCost"
          type="number"
          class="form-control"
          placeholder="Precio Costo"
        />
      </div>
      <div class="col-md-2">
        <input
          v-model.number="newProduct.stock"
          type="number"
          class="form-control"
          placeholder="Stock"
        />
      </div>
      <div class="col-md-3">
        <input
          type="file"
          class="form-control"
          @change="handleFileChange"
          accept="image/*"
        />
      </div>
      <div class="col-md-2">
        <button type="submit" class="btn btn-primary">Agregar</button>
      </div>
    </form>
  
    <table class="table table-striped">
      <thead>
        <tr>
          <th>Imagen</th>
          <th>Nombre</th>
          <th>Precio Venta</th>
          <th>Precio Costo</th>
          <th>Stock</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="product in products" :key="product.id">
          <td>
            <img
              :src="product.imageUrl ? product.imageUrl : genericImage"
              alt="Product Image"
              style="width:100px; height:100px; object-fit:cover;"
            />
          </td>
          <td>{{ product.name }}</td>
          <td>{{ product.priceSale }}</td>
          <td>{{ product.priceCost }}</td>
          <td>{{ product.stock }}</td>
          <td>
            <button
              class="btn btn-sm btn-warning me-2"
              @click="edit(product)"
            >
              Editar
            </button>
            <button
              class="btn btn-sm btn-danger"
              @click="remove(product.id)"
            >
              Eliminar
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  
    <!-- Modal para editar producto -->
    <div class="modal" tabindex="-1" ref="editModal">
      <div class="modal-dialog">
        <div class="modal-content">
          <form @submit.prevent="updateProduct">
            <div class="modal-header">
              <h5 class="modal-title">Editar Producto</h5>
              <button type="button" class="btn-close" @click="closeModal"></button>
            </div>
            <div class="modal-body">
              <div class="mb-3">
                <label>Nombre</label>
                <input v-model="editProductData.name" type="text" class="form-control" />
              </div>
              <div class="mb-3">
                <label>Precio Venta</label>
                <input v-model.number="editProductData.priceSale" type="number" class="form-control" />
              </div>
              <div class="mb-3">
                <label>Precio Costo</label>
                <input v-model.number="editProductData.priceCost" type="number" class="form-control" />
              </div>
              <div class="mb-3">
                <label>Stock</label>
                <input v-model.number="editProductData.stock" type="number" class="form-control" />
              </div>
              <div class="mb-3">
                <label>Imagen</label>
                <input
                  type="file"
                  class="form-control"
                  @change="handleEditFileChange"
                  accept="image/*"
                />
                <div class="mt-2">
                  <img
                    :src="editProductData.imageUrl ? editProductData.imageUrl : genericImage"
                    alt="Product Image"
                    style="width:100px; height:100px; object-fit:cover;"
                  />
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" @click="closeModal">Cerrar</button>
              <button type="submit" class="btn btn-primary">Guardar</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  
  </div>
</template>
  
<script>
import { ref, onMounted } from 'vue'
import { db } from '../firebase'
import {
  collection,
  addDoc,
  getDocs,
  doc,
  updateDoc,
  deleteDoc
} from 'firebase/firestore'
import {
  getStorage,
  ref as storageRef,
  uploadBytes,
  getDownloadURL
} from 'firebase/storage'
  
export default {
  name: 'Products',
  setup() {
    const businessId = localStorage.getItem('businessId') || ''
    const products = ref([])
    const newProduct = ref({
      name: '',
      priceSale: 0,
      priceCost: 0,
      stock: 0,
      imageUrl: ''
    })
    const newProductImage = ref(null)
    const genericImage = 'https://via.placeholder.com/300?text=No+Image'
  
    const editModal = ref(null)
    const editProductData = ref({
      id: null,
      name: '',
      priceSale: 0,
      priceCost: 0,
      stock: 0,
      imageUrl: ''
    })
    const editProductImage = ref(null)
  
    const productsCol = collection(db, 'businesses', businessId, 'products')
    const storage = getStorage()
  
    const fetchProducts = async () => {
      const snap = await getDocs(productsCol)
      products.value = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
    }
  
    const handleFileChange = (e) => {
      const file = e.target.files[0]
      newProductImage.value = file
    }
  
    const handleEditFileChange = (e) => {
      const file = e.target.files[0]
      editProductImage.value = file
    }
  
    const uploadImage = async (file, productName) => {
      const filePath = `businesses/${businessId}/products/${productName}_${Date.now()}`
      const imgRef = storageRef(storage, filePath)
      await uploadBytes(imgRef, file)
      const url = await getDownloadURL(imgRef)
      return url
    }
  
    const addProduct = async () => {
      if (!newProduct.value.name) return
      // Si hay imagen, subirla y obtener URL
      if (newProductImage.value) {
        const url = await uploadImage(newProductImage.value, newProduct.value.name)
        newProduct.value.imageUrl = url
      }
      await addDoc(productsCol, { ...newProduct.value })
      newProduct.value = { name: '', priceSale: 0, priceCost: 0, stock: 0, imageUrl: '' }
      newProductImage.value = null
      fetchProducts()
    }
  
    const edit = (product) => {
      editProductData.value = { ...product }
      editProductImage.value = null
      showModal()
    }
  
    const showModal = () => {
      if (editModal.value) {
        const modalElement = editModal.value
        const modal = new bootstrap.Modal(modalElement)
        modal.show()
      }
    }
  
    const closeModal = () => {
      if (editModal.value) {
        const modalElement = editModal.value
        const modal = bootstrap.Modal.getInstance(modalElement)
        modal.hide()
      }
    }
  
    const updateProduct = async () => {
      // Si se selecciona nueva imagen, se actualiza la URL
      if (editProductImage.value) {
        const url = await uploadImage(editProductImage.value, editProductData.value.name)
        editProductData.value.imageUrl = url
      }
      const docRef = doc(db, 'businesses', businessId, 'products', editProductData.value.id)
      await updateDoc(docRef, {
        name: editProductData.value.name,
        priceSale: editProductData.value.priceSale,
        priceCost: editProductData.value.priceCost,
        stock: editProductData.value.stock,
        imageUrl: editProductData.value.imageUrl
      })
      closeModal()
      fetchProducts()
    }
  
    const remove = async (id) => {
      await deleteDoc(doc(db, 'businesses', businessId, 'products', id))
      fetchProducts()
    }
  
    onMounted(() => {
      fetchProducts()
    })
  
    return {
      products,
      newProduct,
      addProduct,
      edit,
      remove,
      editModal,
      editProductData,
      showModal,
      closeModal,
      updateProduct,
      handleFileChange,
      handleEditFileChange,
      genericImage
    }
  }
}
</script>
  
<style scoped>
/* Ajusta el estilo según sea necesario */
</style>

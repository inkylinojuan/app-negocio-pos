<!-- src/pages/DomicilioOperativo.vue -->
<template>
    <div class="container mt-5">
      <h2>Pedidos de Domicilio (Operativo)</h2>
      <table class="table table-striped">
        <thead>
          <tr>
            <th>Factura ID</th>
            <th>Total</th>
            <th>Fecha</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="invoice in invoices" :key="invoice.id">
            <td>{{ invoice.id }}</td>
            <td>{{ invoice.total }}</td>
            <td>
              {{ invoice.createdAt ? new Date(invoice.createdAt.seconds * 1000).toLocaleString() : '' }}
            </td>
            <td>
              <button class="btn btn-info btn-sm" @click="viewInvoice(invoice)">Ver / Imprimir</button>
              <button class="btn btn-success btn-sm ms-2" @click="markAsDelivered(invoice.id)">
                Marcar como Pagado/Entregado
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </template>
  
  <script>
  import { ref, onMounted } from 'vue'
  import { collection, query, where, getDocs, updateDoc, doc } from 'firebase/firestore'
  import { db } from '../firebase'
  
  export default {
    name: 'DomicilioOperativo',
    setup() {
      const invoices = ref([])
      const businessId = localStorage.getItem('businessId') || ''
  
      const fetchInvoices = async () => {
        const invoicesCol = collection(db, 'businesses', businessId, 'invoices')
        // Filtrar facturas con paymentMethod 'delivery' y status 'pending_delivery'
        const q = query(invoicesCol, where('paymentMethod', '==', 'delivery'), where('status', '==', 'pending_delivery'))
        const snap = await getDocs(q)
        invoices.value = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
      }
  
      const markAsDelivered = async (invoiceId) => {
        const invoiceDoc = doc(db, 'businesses', businessId, 'invoices', invoiceId)
        // Actualizar el estado de la factura, por ejemplo a 'delivered'
        await updateDoc(invoiceDoc, { status: 'delivered' })
        fetchInvoices()
      }
  
      const viewInvoice = (invoice) => {
        // Aquí podrías abrir un modal o redirigir a una vista detallada para mostrar la factura
        alert(`Factura ${invoice.id}:\nTotal: ${invoice.total}`)
      }
  
      onMounted(() => {
        fetchInvoices()
      })
  
      return { invoices, markAsDelivered, viewInvoice }
    }
  }
  </script>
  
  <style scoped>
  /* Agrega estilos personalizados si lo deseas */
  </style>
  
<template>
    <div class="container mt-5">
      <h2>Gestión de Turno</h2>
      <div v-if="loading">
        <p>Cargando información...</p>
      </div>
      <div v-else>
        <!-- Si no hay turno abierto, mostrar formulario para abrir turno -->
        <div v-if="!openTurn">
          <h3>Abrir Turno</h3>
          <form @submit.prevent="openNewTurn">
            <div v-for="product in products" :key="product.id" class="mb-3">
              <label>
                {{ product.name }} (Stock actual: {{ product.stock }})
              </label>
              <input
                type="number"
                class="form-control"
                v-model.number="inventoryInitial[product.id]"
                min="0"
                placeholder="Cantidad inicial"
              />
            </div>
              <!-- Campo para registrar novedad en el inventario -->
              <div class="form-group">
                <label for="inventoryNote">Novedad en Inventario</label>
                <input
                  type="text"
                  id="inventoryNote"
                  v-model="inventoryNote"
                  placeholder="Ingrese cualquier novedad del inventario"
                />
              </div>
            <button type="submit" class="btn btn-primary">
              Abrir Turno
            </button>
          </form>
        </div>
        <!-- Si hay turno abierto, mostrar la tabla para cierre -->
        <div v-else>
          <h3>Turno Abierto</h3>
          <p>
            Iniciado el:
            {{ openTurn.openedAt ? new Date(openTurn.openedAt.seconds * 1000).toLocaleString() : '' }}
          </p>
          <h4>Cierre de Turno</h4>
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Inventario Inicial</th>
                <th>Inventario Final</th>
                <th>Cantidad Vendida</th>
                <th>Valor del Producto</th>
                <th>Venta Total</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="product in products" :key="product.id">
                <td>{{ product.name }}</td>
                <td>{{ openTurn.inventoryInitial[product.id] }}</td>
                <td>
                  <input
                    type="number"
                    class="form-control"
                    v-model.number="inventoryFinal[product.id]"
                    min="0"
                  />
                </td>
                <td>{{ soldQuantity(product.id) }}</td>
                <td>{{ product.priceSale }}</td>
                <td>{{ saleTotal(product.id) }}</td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <th colspan="5">Total Ventas</th>
                <th>{{ totalSales }}</th>
              </tr>
            </tfoot>
          </table>
          <button class="btn btn-danger" @click="closeTurn">
            Cerrar Turno
          </button>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  import { ref, computed, onMounted } from 'vue'
  import { auth, db } from '../firebase'
  import {
    collection,
    getDocs,
    addDoc,
    query,
    where,
    serverTimestamp,
    doc,
    getDoc,
    updateDoc
  } from 'firebase/firestore'
  
  export default {
    name: 'TurnManager',
    setup() {
      const loading = ref(true)
      const openTurn = ref(null)
      const products = ref([])
      const inventoryInitial = ref({})
      const inventoryFinal = ref({})
      const businessId = localStorage.getItem('businessId') || ''
      const inventoryNote = ref('')

  
      const currentUserUid = auth.currentUser ? auth.currentUser.uid : ''
  
      // Función para obtener los productos
      const fetchProducts = async () => {
        const productsCol = collection(db, 'businesses', businessId, 'products')
        const snap = await getDocs(productsCol)
        products.value = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
        // Inicializar inventoryInitial con 0 para cada producto
        products.value.forEach(product => {
          inventoryInitial.value[product.id] = product.stock || 0
        })
      }
  
      // Función para buscar si hay un turno abierto para el usuario actual
      const fetchOpenTurn = async () => {
        const turnsCol = collection(db, 'businesses', businessId, 'turns')
        const q = query(
          turnsCol,
          where('assignedTo', '==', currentUserUid),
          where('status', '==', 'open')
        )
        const snap = await getDocs(q)
        if (!snap.empty) {
          // Se asume que solo hay un turno abierto
          localStorage.setItem('currentTurnId', currentUserUid)
          openTurn.value = { id: snap.docs[0].id, ...snap.docs[0].data() }
          // Inicializar inventoryFinal con los valores actuales (si existen) o 0
          for (const productId in openTurn.value.inventoryInitial) {
            inventoryFinal.value[productId] =
              openTurn.value.inventoryFinal && openTurn.value.inventoryFinal[productId]
                ? openTurn.value.inventoryFinal[productId]
                : 0
          }
        } else {
          openTurn.value = null
        }
      }
  
      // Abrir un nuevo turno (si no hay uno abierto)
      const openNewTurn = async () => {
        const turnsCol = collection(db, 'businesses', businessId, 'turns')
        const turnData = {
          inventoryNote: inventoryNote.value,
          assignedTo: currentUserUid,
          openedBy: currentUserUid,
          openedAt: serverTimestamp(),
          status: 'open',
          inventoryInitial: { ...inventoryInitial.value },
          inventoryFinal: {}
        }
        const docRef = await addDoc(turnsCol, turnData)
        await fetchOpenTurn() // Actualiza la variable openTurn
      }
  
      // Cerrar el turno abierto
      const closeTurn = async () => {
  // Validar que el inventario final no sea mayor que el inventario inicial para cada producto
  for (const productId in openTurn.value.inventoryInitial) {
    if (inventoryFinal.value[productId] > openTurn.value.inventoryInitial[productId]) {
      alert(
        `Error: El inventario final para ${getProductName(productId)} no puede ser mayor que el inicial.`
      )
      return
    }
  }
  const turnDoc = doc(db, 'businesses', businessId, 'turns', openTurn.value.id)
  await updateDoc(turnDoc, {
    inventoryFinal: { ...inventoryFinal.value },
    status: 'closed',
    closedAt: serverTimestamp()
  })
  
  // Actualizar el stock en la colección de productos con el inventario final
  for (const productId in inventoryFinal.value) {
    const productDoc = doc(db, 'businesses', businessId, 'products', productId)
    await updateDoc(productDoc, { stock: inventoryFinal.value[productId] })
  }
  
  // Reiniciar la variable openTurn para que se muestre la interfaz de apertura
  openTurn.value = null
  alert('Turno cerrado y stock actualizado correctamente.')
}

  
      // Funciones auxiliares para el cierre del turno
      const soldQuantity = (productId) => {
        const initial = openTurn.value.inventoryInitial[productId] || 0
        const final = inventoryFinal.value[productId] || 0
        return initial - final
      }
  
      const saleTotal = (productId) => {
        return soldQuantity(productId) * (getProduct(productId)?.priceSale || 0)
      }
  
      const getProduct = (productId) => {
        return products.value.find(p => p.id === productId)
      }
  
      const getProductName = (productId) => {
        const prod = getProduct(productId)
        return prod ? prod.name : productId
      }
  
      const totalSales = computed(() => {
        let total = 0
        for (const product of products.value) {
          total += saleTotal(product.id)
        }
        return total
      })
  
      onMounted(async () => {
        await fetchProducts()
        await fetchOpenTurn()
        loading.value = false
      })
  
      return {
        loading,
        openTurn,
        products,
        inventoryInitial,
        inventoryFinal,
        openNewTurn,
        closeTurn,
        soldQuantity,
        saleTotal,
        totalSales,
        getProductName,
        inventoryNote
      }
    }
  }
  </script>
  
  <style scoped>
.turn-manager {
  /* Tus estilos aquí */
}

.form-group {
  margin-bottom: 1rem;
}

label {
  display: block;
  margin-bottom: 0.5rem;
}

input[type="text"] {
  width: 100%;
  padding: 0.5rem;
  font-size: 1rem;
}
  </style>
  
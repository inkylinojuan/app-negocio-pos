<template>
  <div class="container mt-5">
    <h2>Punto de Venta</h2>
    <div class="row">
      <!-- Columna Izquierda: Productos y Combos -->
      <div class="col-md-8">
        <h3>Productos Individuales</h3>
        <div class="row">
          <div class="col-md-3 mb-3" v-for="product in products" :key="product.id">
            <div class="card">
              <img
                :src="product.imageUrl ? product.imageUrl : genericImage"
                class="card-img-top"
                style="width:200px; height:200px; object-fit:cover;"
                alt="Product Image"
              />
              <div class="card-body">
                <h5 class="card-title">{{ product.name }}</h5>
                <p>Precio: {{ product.priceSale }}</p>
                <button class="btn btn-primary" @click="addToCart(product)">
                  Agregar
                </button>
              </div>
            </div>
          </div>
        </div>
        <h3>Combos</h3>
        <div class="row">
          <div class="col-md-3 mb-3" v-for="combo in combos" :key="combo.id">
            <div class="card">
              <img
                :src="combo.imageUrl ? combo.imageUrl : genericImage"
                class="card-img-top"
                style="width:200px; height:200px; object-fit:cover;"
                alt="Combo Image"
              />
              <div class="card-body">
                <h5 class="card-title">{{ combo.name }}</h5>
                <p>Precio: {{ combo.priceSale }}</p>
                <ul>
                  <li v-for="(comp, index) in combo.components" :key="index">
                    {{ getProductName(comp.productId) }} x {{ comp.quantity }}
                  </li>
                </ul>
                <button class="btn btn-primary" @click="addComboToCart(combo)">
                  Agregar Combo
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Columna Derecha: Carrito -->
      <div class="col-md-4">
        <div class="sticky-top" style="top: 20px;">
          <!-- Sección Carrito -->
          <div v-if="cart.length > 0">
            <h4>Carrito {{ invoiceNumber }}</h4>
            <table class="table table-striped">
  <thead>
    <tr>
      <th>Producto / Combo</th>
      <th>Cantidad</th>
      <th>Precio</th>
      <th>Total</th>
      <th>Acciones</th>
    </tr>
  </thead>
  <tbody>
    <template v-for="(item, index) in cart" :key="item.id">
      <!-- Fila normal -->
      <tr>
        <td>
          <template v-if="!item.isCombo">
            {{ item.name }}
          </template>
          <template v-else>
            {{ item.name }} (Combo)
            <!-- Sublista con los componentes -->
            <ul>
              <li v-for="(comp, compIndex) in item.components" :key="compIndex">
                {{ getProductName(comp.productId) }} x {{ comp.quantity }}
              </li>
            </ul>
          </template>
        </td>
        <td>{{ item.quantity }}</td>
        <td>{{ item.priceSale }}</td>
        <td>{{ item.quantity * item.priceSale }}</td>
        <td>
          <button class="btn btn-danger btn-sm" @click="removeFromCart(index)">Eliminar</button>
          <button
            v-if="item.isCombo"
            class="btn btn-warning btn-sm"
            @click="toggleEditCombo(index)"
          >
            {{ item.isEditing ? 'Cancelar Edición' : 'Editar Combo' }}
          </button>
        </td>
      </tr>
      <!-- Fila de edición para combos -->
      <tr v-if="item.isCombo && item.isEditing">
        <td colspan="5">
          <div v-for="(comp, compIndex) in item.editingComponents" :key="compIndex" class="mb-2">
            <label>Producto:</label>
            <select
              v-model="comp.productId"
              class="form-select d-inline-block"
              style="width: auto; margin-right:10px;"
            >
              <option v-for="prod in products" :key="prod.id" :value="prod.id">
                {{ prod.name }}
              </option>
            </select>
            <label>Cantidad:</label>
            <input
              type="number"
              v-model.number="comp.quantity"
              class="form-control d-inline-block"
              style="width: 80px; margin-right:10px;"
              min="1"
            />
          </div>
          <button class="btn btn-success btn-sm" @click="saveComboEdit(index)">
            Guardar
          </button>
          <button class="btn btn-secondary btn-sm" @click="cancelComboEdit(index)">
            Cancelar
          </button>
        </td>
      </tr>
    </template>
  </tbody>
  <tfoot>
    <tr>
      <th colspan="3">Total a Pagar</th>
      <th colspan="2">{{ total }}</th>
    </tr>
  </tfoot>
</table>


            <!-- Selección de Cliente -->
            <div class="mb-3">
              <label for="customerSelect" class="form-label">Seleccione Cliente:</label>
              <select
                id="customerSelect"
                class="form-select"
                v-model="selectedCustomerId"
                @change="updateCustomer"
              >
                <option value="">Consumidor Final</option>
                <option v-for="client in clientContacts" :key="client.id" :value="client.id">
                  {{ client.name }}
                </option>
              </select>
            </div>
            <!-- Botón para mostrar/ocultar Medios de Pago -->
            <button class="btn btn-success mb-3" @click="togglePayment">
              {{ showPayment ? 'Ocultar Medios de Pago' : 'Cobrar' }}
            </button>
            <!-- Botón para ver/ocultar Factura -->
            <button
              v-if="cart.length > 0"
              class="btn btn-secondary mb-3"
              @click="toggleInvoice"
            >
              {{ showInvoice ? 'Ocultar Factura' : 'Ver Factura' }}
            </button>
          </div>
          <div v-else class="alert alert-info">
            Carrito vacío
          </div>

          <!-- Sección de Medios de Pago -->
          <div v-if="showPayment" class="mt-4">
            <h4>Medios de Pago</h4>
            <div class="btn-group mb-3" role="group">
              <button
                type="button"
                class="btn btn-outline-primary"
                :class="{ active: paymentMethod==='cash' }"
                @click="selectPayment('cash')"
              >
                Efectivo
              </button>
              <button
                type="button"
                class="btn btn-outline-primary"
                :class="{ active: paymentMethod==='qr' }"
                @click="selectPayment('qr')"
              >
                QR / Transferencia
              </button>
              <button
                type="button"
                class="btn btn-outline-primary"
                :class="{ active: paymentMethod==='delivery' }"
                @click="selectPayment('delivery')"
              >
                Domicilio
              </button>
            </div>

            <!-- Campos para Efectivo -->
            <div v-if="paymentMethod==='cash'" class="mb-3">
              <label>Ingresar efectivo recibido:</label>
              <input
                type="number"
                v-model.number="cashReceived"
                class="form-control"
              />
              <p v-if="cashReceived >= total">
                Cambio a devolver: {{ change }}
              </p>
              <p v-else class="text-danger" v-if="cashReceived > 0">
                Efectivo insuficiente.
              </p>
            </div>

            <!-- Campos para Domicilio -->
            <div v-if="paymentMethod==='delivery'" class="mb-3">
              <label>Dirección de Entrega:</label>
              <input
                type="text"
                v-model="deliveryInfo.address"
                class="form-control"
                placeholder="Ingrese la dirección de entrega"
              />
              <label class="mt-2">Teléfono de Entrega:</label>
              <input
                type="text"
                v-model="deliveryInfo.phone"
                class="form-control"
                placeholder="Ingrese el teléfono de entrega"
              />
            </div>

            <button
              class="btn btn-primary"
              @click="registerPayment"
              :disabled="paymentMethod==='cash' && cashReceived < total"
            >
              Registrar Pago
            </button>
          </div>

          <!-- Sección de Factura Inline -->
          <div
            v-if="showInvoice"
            id="invoice1"
            class="mt-4"
            style="position: relative; z-index: 2;"
          >
          <InvoiceTemplate
            v-if="businessInfo"
            :businessInfo="businessInfo"
            :invoiceNumber="invoiceNumber"
            :invoiceDate="invoiceDate"
            :paymentMethod="paymentMethod"
            :sellerName="sellerName"
            :dueDate="dueDate"
            :customer="customer"
            :cart="cart"
            :subtotal="total"
            :tax="tax"
            :total="total"
            :deliveryInfo="deliveryInfo"
            :products="products"
          />

            <button class="btn btn-primary mt-3" @click="printInvoice">
              Imprimir Factura
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { ref, computed, onMounted } from 'vue'
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  serverTimestamp,
  doc,
  getDoc,
  query,
  where,
  runTransaction
} from 'firebase/firestore'
import { db } from '../firebase'
import InvoiceTemplate from '../components/InvoiceTemplate.vue'
import { useInventory } from '../composables/useInventory'
import { useBusinessInfo } from '../composables/useBusinessInfo'

export default {
  name: 'SalesPOS',
  props: {
    businessId: {
      type: String,
      required: true,
      default: () => localStorage.getItem('businessId') || ''
    }
  },
  components: { InvoiceTemplate },
  setup(props) {
    // Datos de negocio
    const { businessInfo, fetchBusinessInfo } = useBusinessInfo(props.businessId)

    // Productos, combos y carrito
    const products = ref([])
    const combos = ref([])
    const cart = ref([])
    const genericImage = ref('https://via.placeholder.com/300?text=No+Image')

    // Inventario
    const { updateInventoryAfterSale } = useInventory(props.businessId)

    // Mostrar/ocultar secciones
    const showPayment = ref(false)
    const showInvoice = ref(false)
    const togglePayment = () => {
      showPayment.value = !showPayment.value
    }
    const toggleInvoice = () => {
      showInvoice.value = !showInvoice.value
    }

    // Cargar productos y combos
    const fetchProducts = async () => {
      const productsCol = collection(db, 'businesses', props.businessId, 'products')
      const snap = await getDocs(productsCol)
      products.value = snap.docs.map(d => ({ id: d.id, ...d.data() }))
    }
    const fetchCombos = async () => {
      const combosCol = collection(db, 'businesses', props.businessId, 'combos')
      const snap = await getDocs(combosCol)
      combos.value = snap.docs.map(d => ({ id: d.id, ...d.data() }))
    }

    // Agregar al carrito
    const addToCart = (product) => {
      const existingItem = cart.value.find(item => item.id === product.id && !item.isCombo)
      if (existingItem) {
        existingItem.quantity++
      } else {
        cart.value.push({ ...product, quantity: 1, isCombo: false })
      }
    }
    const addComboToCart = (combo) => {
      const existingCombo = cart.value.find(item => item.id === combo.id && item.isCombo)
      if (existingCombo) {
        existingCombo.quantity++
      } else {
        // Se inicializa el combo sin estado de edición
        cart.value.push({ ...combo, quantity: 1, isCombo: true, isEditing: false })
      }
    }

    // Obtener nombre del producto
    const getProductName = (productId) => {
      const prod = products.value.find(p => p.id === productId)
      return prod ? prod.name : productId
    }

    // Cálculo de totales
    const total = computed(() =>
      cart.value.reduce((acc, item) => acc + item.priceSale * item.quantity, 0)
    )

    // Métodos para eliminación y edición de combos en el carrito
    const removeFromCart = (index) => {
      cart.value.splice(index, 1)
    }
    const toggleEditCombo = (index) => {
      let item = cart.value[index]
      if (item.isCombo) {
        if (!item.isEditing) {
          // Iniciar edición: clonar componentes en editingComponents
          item.editingComponents = JSON.parse(JSON.stringify(item.components))
          item.isEditing = true
        } else {
          // Cancelar edición
          item.isEditing = false
          delete item.editingComponents
        }
      }
    }
    const saveComboEdit = (index) => {
      let item = cart.value[index]
      if (item.isCombo && item.isEditing) {
        // Guardar los cambios en los componentes personalizados
        item.components = item.editingComponents
        item.isEditing = false
        delete item.editingComponents
      }
    }
    const cancelComboEdit = (index) => {
      let item = cart.value[index]
      if (item.isCombo && item.isEditing) {
        // Revertir cambios y cancelar edición
        item.isEditing = false
        delete item.editingComponents
      }
    }

    // Variables de pago
    const paymentMethod = ref('')
    const cashReceived = ref(0)
    const normalizedCashReceived = computed(() => {
      const val = Number(cashReceived.value)
      return isNaN(val) ? 0 : val
    })
    const change = computed(() => {
      if (paymentMethod.value === 'cash' && normalizedCashReceived.value >= total.value) {
        return normalizedCashReceived.value - total.value
      }
      return 0
    })
    const isDelivery = ref(false)
    const deliveryInfo = ref({ address: '', phone: '' })
    const selectPayment = (method) => {
      paymentMethod.value = method
      isDelivery.value = (method === 'delivery')
    }

    // Manejo de números de factura
    const invoiceNumber = ref(2)
    const getInvoiceNumber = async () => {
      const counterDocRef1 = doc(db, 'businesses', props.businessId, "counters", "invoices")
      try {
        const productSnap1 = await getDoc(counterDocRef1)
        invoiceNumber.value = productSnap1.data().counter + 1
      } catch (e) {
        console.error("Error al obtener el siguiente número de factura:", e)
      }
    }
    const getNextInvoiceNumber = async () => {
      const counterDocRef = doc(db, 'businesses', props.businessId, "counters", "invoices")
      try {
        const newInvoiceNumber = await runTransaction(db, async (transaction) => {
          const counterDoc = await transaction.get(counterDocRef)
          if (!counterDoc.exists()) {
            transaction.set(counterDocRef, { counter: 1 })
            return 1
          }
          const currentCounter = counterDoc.data().counter
          const nextCounter = currentCounter + 1
          transaction.update(counterDocRef, { counter: nextCounter })
          return nextCounter
        })
        invoiceNumber.value = newInvoiceNumber
        return newInvoiceNumber
      } catch (e) {
        console.error("Error al obtener el siguiente número de factura:", e)
        return 0
      }
    }

    // Registrar pago y actualizar inventario
    const currentTurnId = ref(localStorage.getItem('currentTurnId') || '')
    const currentFullName = ref(localStorage.getItem('fullName') || '')
    const customer = ref({
      name: 'Consumidor Final',
      address: 'NA',
      phone: 'NA',
      document: '888888888-8'
    })
    const registerPayment = async () => {
      const newInvoiceNumber = await getNextInvoiceNumber()
      const invoiceData = {
        invoiceNumber: newInvoiceNumber,
        cart: cart.value,
        total: total.value,
        paymentMethod: paymentMethod.value,
        turnId: currentTurnId.value,
        createdAt: serverTimestamp(),
        customer: customer.value
      }
      if (paymentMethod.value === 'cash') {
        invoiceData.cashReceived = normalizedCashReceived.value
        invoiceData.change = change.value
        invoiceData.status = 'paid'
      } else if (paymentMethod.value === 'qr') {
        invoiceData.status = 'paid'
      } else if (paymentMethod.value === 'delivery') {
        invoiceData.status = 'pending_delivery'
      }

      await addDoc(collection(db, 'businesses', props.businessId, 'invoices'), invoiceData)

      // Actualizar stock: para combos se usa el arreglo actualizado de componentes (posiblemente editado)
      for (const item of cart.value) {
        if (item.isCombo) {
          for (const comp of item.components) {
            const productDoc = doc(db, 'businesses', props.businessId, 'products', comp.productId)
            const productSnap = await getDoc(productDoc)
            if (productSnap.exists()) {
              const currentStock = productSnap.data().stock || 0
              const newStock = currentStock - (item.quantity * comp.quantity)
              await updateDoc(productDoc, { stock: newStock })
            }
          }
        } else {
          const productDoc = doc(db, 'businesses', props.businessId, 'products', item.id)
          const productSnap = await getDoc(productDoc)
          if (productSnap.exists()) {
            const currentStock = productSnap.data().stock || 0
            const newStock = currentStock - item.quantity
            await updateDoc(productDoc, { stock: newStock })
          }
        }
      }

      // Resetear variables y carrito
      cart.value = []
      showPayment.value = false
      showInvoice.value = false
      paymentMethod.value = ''
      cashReceived.value = 0
      isDelivery.value = false
      await getInvoiceNumber()

      alert('Pago registrado y venta completada.')
    }

    // Datos de factura
    const invoiceDate = ref(new Date().toLocaleString())
    const sellerName = ref(currentFullName.value)
    const dueDate = ref(new Date().toLocaleDateString())
    const subtotal = ref(total.value)
    const tax = ref(0)

    // Función para imprimir la factura
    const printInvoice = () => {
      const invoiceElement = document.getElementById('invoice')
      if (!invoiceElement) {
        console.error("No se encontró el elemento con id 'invoice'")
        return
      }
      const invoiceContent = invoiceElement.innerHTML
      const printWindow = window.open('', '', 'height=600,width=400')
      printWindow.document.write('<html><head><title>Factura</title>')
      printWindow.document.write('<style>')
      printWindow.document.write(`
        @page {
          size: 60mm auto;
          margin: 2mm;
        }
        body {
          width: 60mm;
          margin: 0 auto;
          padding: 0;
          font-family: Arial, sans-serif;
          font-size: 10px;
        }
        .invoice-template {
          width: 100%;
          margin: 0;
          padding: 0;
        }
        .header, .invoice-info, .customer-info, .cart-info, .additional-info, .footer {
          text-align: center;
          margin: 0;
          padding: 0;
          line-height: 1.2;
        }
        .table {
          width: 100%;
          border-collapse: collapse;
          font-size: 9px;
        }
        .table th, .table td {
          border: none;
          padding: 1px;
          text-align: center;
        }
        .totals {
          margin-top: 2mm;
          text-align: right;
        }
        hr {
          border: none;
          border-top: 1px solid #000;
          margin: 2mm 0;
        }
      `)
      printWindow.document.write('</style>')
      printWindow.document.write('</head><body>')
      printWindow.document.write(invoiceContent)
      printWindow.document.write('</body></html>')
      printWindow.document.close()
      printWindow.focus()
      setTimeout(() => {
        printWindow.print()
        printWindow.close()
      }, 500)
    }

    // Gestión de clientes
    const clientContacts = ref([])
    const selectedCustomerId = ref("")
    const fetchClientContacts = async () => {
      const contactsCol = collection(db, 'businesses', props.businessId, 'contacts')
      const q = query(contactsCol, where('roles', 'array-contains', 'Cliente'))
      const snap = await getDocs(q)
      clientContacts.value = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }))
    }
    const updateCustomer = () => {
      if (selectedCustomerId.value) {
        const client = clientContacts.value.find(c => c.id === selectedCustomerId.value)
        if (client) {
          customer.value = client
        }
      } else {
        customer.value = {
          name: 'Consumidor Final',
          address: 'N/A',
          phone: 'N/A',
          document: ''
        }
      }
    }

    onMounted(async () => {
      await fetchBusinessInfo()
      fetchProducts()
      fetchCombos()
      await fetchClientContacts()
      await getInvoiceNumber()
    })

    return {
      // Datos de negocio y productos
      businessInfo,
      products,
      combos,
      cart,
      genericImage,

      // Mostrar/ocultar secciones
      showPayment,
      togglePayment,
      showInvoice,
      toggleInvoice,

      // Métodos para carrito
      addToCart,
      addComboToCart,
      getProductName,
      removeFromCart,
      toggleEditCombo,
      saveComboEdit,
      cancelComboEdit,

      // Totales y pago
      total,
      paymentMethod,
      selectPayment,
      cashReceived,
      normalizedCashReceived,
      change,
      isDelivery,
      deliveryInfo,

      // Registro de pago e impresión
      currentTurnId,
      registerPayment,
      invoiceNumber,
      invoiceDate,
      sellerName,
      dueDate,
      customer,
      subtotal,
      tax,
      printInvoice,

      // Gestión de clientes
      clientContacts,
      selectedCustomerId,
      updateCustomer
    }
  }
}
</script>

<!-- Estilos de impresión (NO SCOPED) -->
<style>
@media print {
  @page {
    margin: 0;
  }
  html, body {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
  }
  body * {
    visibility: hidden !important;
  }
  #invoice, #invoice * {
    visibility: visible !important;
  }
  #invoice {
    position: absolute;
    top: 0;
    left: 0;
    width: 60mm;
    margin: 0;
    padding: 0;
    page-break-before: avoid;
    page-break-after: avoid;
    page-break-inside: avoid;
  }
}
</style>

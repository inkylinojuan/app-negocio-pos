<!-- src/pages/Login.vue -->
<template>
  <div class="container mt-5">
    <h2>Login</h2>
    <form @submit.prevent="handleLogin">
      <div class="mb-3">
        <label>Email</label>
        <input v-model="email" type="email" class="form-control" required>
      </div>
      <div class="mb-3">
        <label>Password</label>
        <input v-model="password" type="password" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary">Login</button>
    </form>
    <p v-if="errorMessage" class="text-danger mt-3">{{ errorMessage }}</p>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { signInWithEmailAndPassword } from 'firebase/auth'
import { auth, db } from '../firebase'
import { doc, getDoc } from 'firebase/firestore'
import { useRouter } from 'vue-router'
import { useAuthStore } from '../stores/auth'


export default {
  name: 'Login',
  setup() {
    const email = ref('')
    const password = ref('')
    const errorMessage = ref('')
    const router = useRouter()
    const authStore = useAuthStore()

    // Limpia el store y localStorage al cargar el componente
    onMounted(() => {
      authStore.clear()
      localStorage.clear()
    })

    const handleLogin = async () => {
      errorMessage.value = ''
      try {
        const userCredential = await signInWithEmailAndPassword(auth, email.value, password.value)
        const user = userCredential.user
        // Obtener información del usuario (incluyendo businessId y role)
        const userDoc = await getDoc(doc(db, 'users', user.uid))
        if (userDoc.exists()) {
          const userData = userDoc.data()
          // Actualizar el store con la información del usuario
          authStore.setUserInfo({
            fullName: userData.fullName,
            userRole: userData.role,
            businessId: userData.businessId
          })
          // Guardar en localStorage si lo requieres (opcional)
          localStorage.setItem('fullName', userData.fullName)
          localStorage.setItem('userRole', userData.role)
          localStorage.setItem('businessId', userData.businessId)

          // Buscar información del negocio y actualizar el store
          const businessDoc = await getDoc(doc(db, 'businesses', userData.businessId))
          if (businessDoc.exists()) {
            const businessData = businessDoc.data()
            authStore.setBusinessInfo(businessData)
            localStorage.setItem('businessInfo', JSON.stringify(businessData))
          } else {
            console.error("No se encontró información del negocio.")
          }

          // Redireccionar según el rol del usuario
          if (userData.role === 'superadmin') {
            router.push('/superadmin/create-business')
          } else if (userData.role === 'admin') {
            router.push('/admin')
          } else {
            router.push('/operative')
          }
        } else {
          errorMessage.value = 'No se encontró información para este usuario.'
        }
      } catch (error) {
        errorMessage.value = error.message
      }
    }

    return { email, password, errorMessage, handleLogin }
  }
}
</script>
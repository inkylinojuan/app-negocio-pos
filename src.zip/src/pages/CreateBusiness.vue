<template>
  <div class="container mt-5 position-relative">
    <h2>Crear Nuevo Negocio</h2>
    <!-- Formulario de creación de negocio, se oculta si ya se creó -->
    <form v-if="!businessCreated" @submit.prevent="createBusiness">
      <div class="mb-3">
        <label class="form-label">Nombre del Negocio</label>
        <input v-model="business.name" type="text" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Descripción</label>
        <textarea v-model="business.description" class="form-control" required></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label">Dirección</label>
        <input v-model="business.address" type="text" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">NIT</label>
        <input v-model="business.nit" type="text" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Teléfono</label>
        <input v-model="business.phone" type="text" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Correo Electrónico</label>
        <input v-model="business.email" type="email" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Régimen Tributario</label>
        <input v-model="business.taxRegime" type="text" class="form-control" required />
      </div>
      <div class="mb-3">
        <label class="form-label">Pie de Factura</label>
        <textarea
          v-model="business.invoiceFooter"
          class="form-control"
          placeholder="Información de jurisdicción, notas, etc."
          required
        ></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label">Facturador</label>
        <input v-model="business.facturador" type="text" class="form-control" required />
      </div>
      <!-- Campos opcionales para domicilios 
      <div class="mb-3">
        <label class="form-label">Dirección de Entrega (Domicilio)</label>
        <input v-model="business.deliveryAddress" type="text" class="form-control" />
      </div>
      <div class="mb-3">
        <label class="form-label">Teléfono de Entrega (Domicilio)</label>
        <input v-model="business.deliveryPhone" type="text" class="form-control" />
      </div>-->
      <button type="submit" class="btn btn-primary" :disabled="isLoading">Crear Negocio</button>
    </form>
    <p class="mt-3" v-if="message">{{ message }}</p>

    <!-- Sección para crear el usuario admin, que se muestra cuando el negocio ya fue creado -->
    <div v-if="businessCreated" class="mt-5">
      <h3>Crear Usuario Admin para el Negocio</h3>
      <form @submit.prevent="createAdminUser">
        <div class="mb-3">
          <label class="form-label">Email</label>
          <input v-model="adminUser.email" type="email" class="form-control" required />
        </div>
        <div class="mb-3">
          <label class="form-label">Contraseña</label>
          <input v-model="adminUser.password" type="password" class="form-control" required />
        </div>
        <button type="submit" class="btn btn-primary">Crear Usuario Admin</button>
      </form>
      <p class="mt-3" v-if="adminMessage">{{ adminMessage }}</p>
    </div>

    <!-- Overlay de Loader -->
    <div v-if="isLoading" class="overlay">
      <div class="spinner-border text-light" role="status">
        <span class="visually-hidden">Cargando...</span>
      </div>
    </div>
  </div>
</template>

<script>
import { ref } from 'vue'
import { collection, addDoc, serverTimestamp, doc, setDoc } from 'firebase/firestore'
import { db, auth } from '../firebase'
import { createUserWithEmailAndPassword } from 'firebase/auth'

export default {
  name: 'CreateBusiness',
  setup() {
    const business = ref({
      name: '',
      description: '',
      address: '',
      nit: '',
      phone: '',
      email: '',
      taxRegime: '',
      invoiceFooter: '',
      facturador: '',
      deliveryAddress: '',
      deliveryPhone: '',
      createdAt: serverTimestamp()
    })

    const message = ref('')
    const businessCreated = ref(false)
    const createdBusinessId = ref('')
    const adminUser = ref({
      email: '',
      password: ''
    })
    const adminMessage = ref('')
    const isLoading = ref(false)

    const createBusiness = async () => {
      try {
        isLoading.value = true
        const businessesCol = collection(db, 'businesses')
        const docRef = await addDoc(businessesCol, business.value)
        createdBusinessId.value = docRef.id
        message.value = `Negocio creado correctamente. ID: ${docRef.id}`
        businessCreated.value = true
      } catch (error) {
        message.value = `Error: ${error.message}`
      } finally {
        isLoading.value = false
      }
    }

    const createAdminUser = async () => {
      try {
        const userCredential = await createUserWithEmailAndPassword(
          auth,
          adminUser.value.email,
          adminUser.value.password
        )
        const user = userCredential.user
        await setDoc(doc(db, 'users', user.uid), {
          email: adminUser.value.email,
          role: 'admin',
          businessId: createdBusinessId.value,
          createdAt: serverTimestamp()
        })
        adminMessage.value = 'Usuario Admin creado correctamente para el negocio.'
      } catch (error) {
        adminMessage.value = `Error al crear usuario admin: ${error.message}`
      }
    }

    return { 
      business, 
      createBusiness, 
      message, 
      businessCreated, 
      adminUser, 
      createAdminUser, 
      adminMessage,
      isLoading 
    }
  }
}
</script>

<style scoped>
/* Overlay para bloquear la interfaz y mostrar el loader */
.overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(128, 128, 128, 0.5);
  z-index: 9999;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>

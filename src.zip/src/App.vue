<template>
  <div>
    <!-- Mostrar el menú si el usuario está autenticado -->
    <Menu v-if="isLoggedIn" />
    <div class="main-content">
      <router-view />
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue'
import { onAuthStateChanged } from 'firebase/auth'
import { auth } from './firebase'
import Menu from './components/Menu.vue'

export default {
  name: 'App',
  components: { Menu },
  setup() {
    const isLoggedIn = ref(false)
    onAuthStateChanged(auth, (user) => {
      isLoggedIn.value = !!user
    })
    return { isLoggedIn }
  }
}
</script>

<style>
.main-content {
  margin-left: 250px; /* debe ser igual al ancho del sidebar */
  padding: 1rem;
}
</style>
